
<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Create Company</h4>
                </div>
                <div class="">
                           <div>
                            <form method="post" action="<?php echo e(URL::to('company-store')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="basic-form">
                                        <input type="hidden" name="company_id" value="<?php echo e((!empty($company->id))?$company->id:''); ?>" class="form-control input-default ">
                                        <h4 class="card-title">Name</h4>
                                        <div class="mb-3">
                                            <input type="text" name="name" value="<?php echo e((!empty($company->name))?$company->name:old('name')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('name')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                            <?php endif; ?>
                                        </div><br>
                                        <h4 class="card-title">Email</h4>
                                        <div class="mb-3">
                                            <input type="text" name="email" value="<?php echo e((!empty($company->email))?$company->email:old('email')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div><br>
                                        <h4 class="card-title">Website</h4>
                                        <div class="mb-3">
                                            <input type="text" name="website" value="<?php echo e((!empty($company->website))?$company->website:old('website')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('website')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('website')); ?></span>
                                            <?php endif; ?>
                                        </div><br>
                                        <h4 class="card-title">Logo</h4>
                                        <div class="input-group">
                                            <div class="form-file">
                                                <input type="file" name="logo" class="form-file-input form-control">
                                            </div>
                                        </div><br>
                                        
                                    </div>
                                    <button type="submit" class="btn btn-primary">Add</button>
                                </div>

                            </form>
                        </div>
                       
                    <div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\employee\resources\views/company/create.blade.php ENDPATH**/ ?>