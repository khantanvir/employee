
<?php $__env->startSection('frontend'); ?>


<section class="contact-form section">
	<div class="container">
		<div class="row">
			
			<div class="col-12">
				<table class="table">
                    <thead>
                      <tr>
                        <th><strong>Id</strong></th>
                        <th><strong>First Name</strong></th>
                        <th><strong>Last Name</strong></th>
                        <th><strong>Company</strong></th>
                        <th><strong>Email</strong></th>
                        <th><strong>Phone</strong></th>
                        <th><strong>Status</strong></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $list_of_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e((!empty(Session::get('employee_id')) && Session::get('employee_id')==$row->id)?'table-primary':''); ?>">
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->first_name); ?></td>
                            <td><?php echo e($row->last_name); ?></td>
                            <td><?php echo e($row->Company->name); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><?php echo e($row->phone); ?></td>
                            <td>
                                <?php if($row->status==0): ?>
                                <span class="badge rounded-pill bg-success">Active</span>
                                <?php endif; ?>
                            </td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="bg-danger text-white p-1">No Item Found</p>
                        <?php endif; ?>
                    </tbody>
                  </table>
                  <nav>
                    <ul class="pagination pagination-xs pagination-gutter  pagination-warning">
                        <?php echo $list_of_employee->links(); ?>

                    </ul>
                </nav>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\employee\resources\views/front/employee.blade.php ENDPATH**/ ?>