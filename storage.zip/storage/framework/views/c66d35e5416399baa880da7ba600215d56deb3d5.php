
<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Create Employee</h4>
                </div>
                <div class="">
                           <div>
                            <form method="post" action="<?php echo e(URL::to('employee-store')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="basic-form">
                                        <input type="hidden" name="employee_id" value="<?php echo e((!empty($employee->id))?$employee->id:''); ?>" class="form-control input-default ">
                                        <h4 class="card-title">First Name</h4>
                                        <div class="mb-3">
                                            <input type="text" name="first_name" value="<?php echo e((!empty($employee->first_name))?$employee->first_name:old('first_name')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('first_name')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                                            <?php endif; ?>
                                        </div><br>
                                        <h4 class="card-title">Last Name</h4>
                                        <div class="mb-3">
                                            <input type="text" name="last_name" value="<?php echo e((!empty($employee->last_name))?$employee->last_name:old('last_name')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('last_name')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                                            <?php endif; ?>
                                        </div><br>

                                        <div class="mb-3">
                                            <h4 class="card-title">Select Company</h4>
                                            <select name="company_id" class="default-select form-control wide mb-3">
                                                <option value="">Select Company</option>
                                                <?php $__currentLoopData = $all_companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e((!empty($employee->company_id) && $employee->company_id==$row->id)?'selected':''); ?> value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('company_id')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('company_id')); ?></span>
                                            <?php endif; ?>
                                        </div><br>


                                        <h4 class="card-title">Email</h4>
                                        <div class="mb-3">
                                            <input type="text" name="email" value="<?php echo e((!empty($employee->email))?$employee->email:old('email')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div><br>
                                        <h4 class="card-title">Phone</h4>
                                        <div class="mb-3">
                                            <input type="text" name="phone" value="<?php echo e((!empty($employee->phone))?$employee->phone:old('phone')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('phone')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                            <?php endif; ?>
                                        </div><br>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Add</button>
                                </div>

                            </form>
                        </div>
                       
                    <div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\employee\resources\views/employee/create.blade.php ENDPATH**/ ?>