
<?php $__env->startSection('frontend'); ?>


<section class="contact-form section">
	<div class="container">
		<div class="row">
			
			<div class="col-12">
				<table class="table">
                    <thead>
                      <tr>
                        <th><strong>Name</strong></th>
                        <th><strong>Id</strong></th>
                        <th><strong>Email</strong></th>
                        <th><strong>Logo</strong></th>
                        <th><strong>Website</strong></th>
                        <th><strong>Status</strong></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $list_of_company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e((!empty(Session::get('company_id')) && Session::get('company_id')==$row->id)?'table-primary':''); ?>">
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><img src="<?php echo e(URL::to('public/company/logo/'.$row->logo)); ?>" width="100px" height="50"></td>
                            <td><?php echo e($row->website); ?></td>
                            <td>
                                <?php if($row->status==0): ?>
                                <span class="badge rounded-pill bg-success">Active</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="bg-danger text-white p-1">No Item Found</p>
                        <?php endif; ?>
                    </tbody>
                  </table>
                  <nav>
                    <ul class="pagination pagination-xs pagination-gutter  pagination-warning">
                        <?php echo $list_of_company->links(); ?>

                    </ul>
                </nav>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('userpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\employee\resources\views/front/company.blade.php ENDPATH**/ ?>