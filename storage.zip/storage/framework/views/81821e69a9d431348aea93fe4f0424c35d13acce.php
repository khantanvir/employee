<div>
    Hi, This is : <?php echo e($name); ?>

</div><?php /**PATH C:\xampp\htdocs\adminpanel\resources\views/mail/sendMail.blade.php ENDPATH**/ ?>